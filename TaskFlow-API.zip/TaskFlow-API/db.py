from pymongo import MongoClient
import config

client = MongoClient(config.MONGODB_CONNECTION_STRING)
db = client.taskflow_db