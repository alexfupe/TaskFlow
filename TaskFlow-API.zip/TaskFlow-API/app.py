from datetime import timedelta
from bp_tasks import bp_tasks
from flask import Flask, jsonify, request
from flask_jwt_extended import JWTManager, create_access_token
from jsonschema import validate
from bp_users import bp_users
from db import db

app = Flask(__name__)

app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=10)
app.config["JWT_SECRET_KEY"] = "super-secret"
jwt = JWTManager(app)

app.register_blueprint(bp_users, url_prefix='/users')
app.register_blueprint(bp_tasks, url_prefix='/tasks')

@app.route("/")
def health_check():
    return "API TaskFlow Online", 200

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        username_input = data.get("username") or data.get("Username")
        password_input = data.get("password") or data.get("Password")
        user = db.users.find_one({
            "username": username_input,
            "password": password_input
        })

        if not user:
            return jsonify({"msg": "Usuario o contraseña incorrectos"}), 401
        user_role = user.get("role") or user.get("Role") or "user"
        
        token_claims = {"role": user_role}
        token = create_access_token(
            identity=str(user['_id']), 
            additional_claims=token_claims
        )
        
        return jsonify({
            "token": token,
            "username": user.get("username"),
            "role": user_role
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)