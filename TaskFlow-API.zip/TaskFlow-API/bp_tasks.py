from bson import ObjectId
from flask import Blueprint, jsonify, request
from db import db
from auth import permission_required
from datetime import datetime

bp_tasks = Blueprint('bp_tasks', __name__)

@bp_tasks.route('/my-tasks', methods=['GET'])
@permission_required('user') 
def get_my_tasks(user_id: ObjectId):
    try:
        user_id_str = str(user_id)
        
        query = {
            "$or": [
                {"assigned_to": user_id},
                {"assigned_users": user_id_str}
            ]
        }
        
        tasks_list = list(db.tasks.find(query))
        
        formatted_tasks = []
        for t in tasks_list:
            formatted_tasks.append({
                "id": str(t.get('_id')),
                "title": str(t.get('title', 'Sin título')),
                "description": str(t.get('description', 'Sin descripción')),
                "status": str(t.get('status', 'PENDIENTE')).upper(),
                "comentario": str(t.get('comentario', '')),
                "createdAt": str(t.get('createdAt', '')),
                "finishedAt": str(t.get('finishedAt', ''))
            })

        return jsonify(formatted_tasks), 200
    except Exception as e:
        print(f"Error detectado: {str(e)}")
        return jsonify({"error": "Error de formato de datos"}), 422

@bp_tasks.route('/', methods=['POST'])
@permission_required('user')
def create_task(user_id: ObjectId):
    try:
        data = request.get_json()
        
        nueva_tarea = {
            "title": data.get("title", "Sin título"),
            "description": data.get("description", ""),
            "status": data.get("status", "PENDIENTE").upper(),
            "assigned_to": user_id, 
            "project_id": None, 
            "updated_at": datetime.utcnow(),
            "comentario": data.get("comentario", ""),
            "createdAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "finishedAt": ""
        }
        
        result = db.tasks.insert_one(nueva_tarea)
        
        return jsonify({
            "message": "Tarea creada exitosamente",
            "id": str(result.inserted_id)
        }), 201
        
    except Exception as e:
        print(f"Error al crear tarea: {str(e)}")
        return jsonify({"error": "Error interno del servidor", "details": str(e)}), 500

@bp_tasks.route('/<task_id>', methods=['PUT'])
@permission_required('user')
def update_task(user_id: ObjectId, task_id: str):
    try:
        data = request.get_json()
        
        campos_a_actualizar = {
            "updated_at": datetime.utcnow()
        }
        
        if "title" in data: campos_a_actualizar["title"] = data["title"]
        if "description" in data: campos_a_actualizar["description"] = data["description"]
        if "comentario" in data: campos_a_actualizar["comentario"] = data["comentario"]
        
        if "status" in data:
            nuevo_estado = data["status"].upper()
            campos_a_actualizar["status"] = nuevo_estado
            if nuevo_estado == "HECHO":
                campos_a_actualizar["finishedAt"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            else:
                campos_a_actualizar["finishedAt"] = "" 
        
        result = db.tasks.update_one(
            {"_id": ObjectId(task_id)},
            {"$set": campos_a_actualizar}
        )
        
        if result.matched_count > 0:
            return jsonify({"message": "Tarea actualizada correctamente"}), 200
        else:
            return jsonify({"error": "Tarea no encontrada"}), 404
            
    except Exception as e:
        print(f"Error al actualizar tarea: {str(e)}")
        return jsonify({"error": "Error interno", "details": str(e)}), 500
    
@bp_tasks.route('/<task_id>', methods=['DELETE'])
@permission_required('user')
def delete_task(user_id: ObjectId, task_id: str):
    try:
        result = db.tasks.delete_one({"_id": ObjectId(task_id)})
        
        if result.deleted_count > 0:
            return jsonify({"message": "Tarea eliminada definitivamente de la base de datos"}), 200
        else:
            return jsonify({"error": "Tarea no encontrada"}), 404
            
    except Exception as e:
        print(f"Error al borrar tarea: {str(e)}")
        return jsonify({"error": "Error interno", "details": str(e)}), 500