import jwt
from functools import wraps
from bson import ObjectId
from flask import jsonify, request

SECRET_KEY = '7f8c9b2e1d4a3f5b6c8e9d0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c'

def permission_required(required_role):
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            auth_header = request.headers.get('Authorization')
            
            if not auth_header or not auth_header.startswith('Bearer '):
                return jsonify({"msg": "Token faltante o inválido"}), 401
            
            token = auth_header.split(" ")[1]

            try:
                data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
                
                user_role = str(data.get("role", "user")).upper()
                if user_role != required_role.upper() and user_role != 'ADMIN':
                    return jsonify({"msg": f"Requiere rol {required_role}"}), 403
                user_id = ObjectId(data.get("user_id"))
                return fn(user_id, *args, **kwargs)

            except jwt.ExpiredSignatureError:
                return jsonify({"msg": "El token ha expirado"}), 401
            except jwt.InvalidTokenError:
                return jsonify({"msg": "Token inválido"}), 422
            except Exception as e:
                return jsonify({"msg": str(e)}), 500
                
        return decorator
    return wrapper