from bson import ObjectId
from flask import Blueprint, jsonify, request
from db import db
from auth import permission_required
from datetime import datetime, timedelta
import jwt 

bp_users = Blueprint('bp_users', __name__)

@bp_users.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        username_input = data.get("Username") or data.get("username")
        password_input = data.get("Password") or data.get("password")

        user = db.users.find_one({
            "Username": username_input, 
            "Password": password_input
        })

        if user:
            db.users.update_one(
                {"_id": user["_id"]},
                {"$set": {"Last_login": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}}
            )

            token = jwt.encode({
                'user_id': str(user['_id']),
                'role': user.get('Role', 'USER'),
                'exp': datetime.utcnow() + timedelta(hours=24)
            }, '7f8c9b2e1d4a3f5b6c8e9d0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c', algorithm='HS256')

            return jsonify({
                "token": token,
                "user": {
                    "Username": user.get("Username", username_input),
                    "Email": user.get("Email", "no-email@taskflow.com"),
                    "Role": user.get("Role", "USER")
                }
            }), 200
        
        return jsonify({"error": "Invalid credentials"}), 401
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@bp_users.route('/logout', methods=['POST'])
@permission_required('user')
def logout(user_id: ObjectId):
    try:
        db.users.update_one(
            {"_id": user_id},
            {"$set": {"Last_logout": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}}
        )
        return jsonify({"message": "Cierre de sesión registrado correctamente"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@bp_users.route('/', methods=['POST'])
def crear_usuario():
    try:
        data = request.get_json()
        nuevo_usuario = {
            "Username": data.get("Username") or data.get("username"),
            "Password": data.get("Password") or data.get("password"),
            "Email": data.get("Email") or data.get("email"),
            "Role": (data.get("Role") or data.get("role", "USER")).upper(),
            "Active": True,
            "Created_at": datetime.now() 
        }
        db.users.insert_one(nuevo_usuario)
        return jsonify({"result": "User created"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@bp_users.route('/change-password', methods=['PUT'])
@permission_required('user')
def change_password(user_id: ObjectId):
    try:
        data = request.get_json()
        new_password = data.get("newPassword")

        if not new_password:
            return jsonify({"error": "La nueva contraseña es obligatoria"}), 400

        result = db.users.update_one(
            {"_id": user_id},
            {"$set": {"Password": new_password}} 
        )

        if result.modified_count > 0 or result.matched_count > 0:
            return jsonify({"message": "Contraseña actualizada exitosamente"}), 200
        else:
            return jsonify({"error": "No se pudo actualizar la contraseña"}), 400

    except Exception as e:
        return jsonify({"error": str(e)}), 500